// 1. convert radian to degree
radianToDegree

// 2. check whether the given file name is a javascript file or not
isJavaScriptFile

// 3. calculate the total oil price that I have to pay
/*
* diesel ---> 114
* petrol ---> 130
* octane ---> 135
*/ 
oilPrice

// 4. 
/*
* reserved bus ----> 50
* microbus -----> 11
* rest people will go by public bus
    
total people: 65
    bus remaining: 15
    microbus: 4
    public bus: 4
    public bus fare: 250  


    total people: 129
    bus remaining: 29
    microbus: 7
    public bus fare: ??


    total people: 263
    bus remaining: 13
    micrbus remaining: 2
    public bus: ??
*/ 
publicBusFare

// 5. 
/*
    {name: 'Tom', friend: 'Rock'},
    {name: 'Rock', friend: 'Tom'}
    * true


    {name: 'Chris', friend: 'John'},
    {name: 'raz', friend: 'Jony'}
    * false
*/ 
isBestFriend